package com.microservicio1.peliculas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PeliculasApplicationTests {

	@Test
	void contextLoads() {
	}

}
